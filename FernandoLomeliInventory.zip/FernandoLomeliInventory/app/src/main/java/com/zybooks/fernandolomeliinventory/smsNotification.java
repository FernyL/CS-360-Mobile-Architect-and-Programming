package com.zybooks.fernandolomeliinventory;

import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

//This class sets the Alert Dialog title and message with the positive and negative buttons
public class smsNotification {

    public static AlertDialog doubleButton(final InventoryActivity context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.sms_title)
                .setCancelable(false)
                .setMessage(R.string.sms_msg)

                //Button to allow permissions
                .setPositiveButton(R.string.sms_positive_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Allowed", Toast.LENGTH_LONG).show();
                    InventoryActivity.AllowSendSMS();
                    dialog.cancel();
                })

                //Button to not allow permissions
                .setNegativeButton(R.string.sms_negative_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disabled", Toast.LENGTH_LONG).show();
                    InventoryActivity.DeclineSendSMS();
                    dialog.cancel();
                });

        return builder.create();
    }
}
