package com.zybooks.fernandolomeliinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//SQLite database to hold user login information
public class LoginDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "userInfo.db";
    private static final int VERSION = 1;

    public LoginDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //Initialize table with name and columns
    private static final class LoginTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_EMAIL = "email";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_EMAIL + " text, " +
                LoginTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    //Function to add a user to the database
    public Boolean addUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_EMAIL, email);
        values.put(LoginTable.COL_PASSWORD, password);

        long userId = db.insert(LoginTable.TABLE, null, values);

        return userId != -1;
    }

    //Function to confirm the user email exists
    public Boolean checkEmail(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from users where email = ?", new String[]{email});
        if (cursor.getCount() > 0) {
            return true;
        }else {
            return false;
        }
    }

    //Function to confirm the user email and password exist
    public Boolean checkUser(String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from users where email = ? and password = ?", new String[]{email, password});
        if (cursor.getCount() > 0) {
            return true;
        }else {
            return false;
        }
    }
}
