package com.zybooks.fernandolomeliinventory;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

//Allows newly created items to be added to the inventory list
public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder>{

    //Initialize/declare fields
    Activity activity;
    private Context context;
    private ArrayList itemID, itemName, itemQuantity;

    ListAdapter(Activity activity, Context context, ArrayList itemID, ArrayList itemName, ArrayList itemQuantity) {
        this.activity = activity;
        this.context = context;
        this.itemID = itemID;
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflator = LayoutInflater.from(context);
        View view = inflator.inflate(R.layout.custom_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        holder.itemID_txt.setText(String.valueOf(itemID.get(position)));
        holder.itemName_txt.setText(String.valueOf(itemName.get(position)));
        holder.itemQuantity_txt.setText(String.valueOf(itemQuantity.get(position)));

        //Send SMS notification if item count is 0
        String value = holder.itemQuantity_txt.getText().toString().trim();
        if (value.equals("0")) {
            InventoryActivity.SendSMSMessage(context.getApplicationContext());
        }

        holder.customList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (context, EditItemActivity.class);
                intent.putExtra("id", String.valueOf(itemID.get(position)));
                intent.putExtra("Name", String.valueOf(itemName.get(position)));
                intent.putExtra("Quantity", String.valueOf(itemQuantity.get(position)));
                activity.startActivityForResult(intent, 1);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemName.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView itemID_txt, itemName_txt, itemQuantity_txt;
        LinearLayout customList;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemID_txt = itemView.findViewById(R.id.itemID);
            itemName_txt = itemView.findViewById(R.id.itemName);
            itemQuantity_txt = itemView.findViewById(R.id.itemQuantity);
            customList = itemView.findViewById(R.id.customList);
        }
    }
}
