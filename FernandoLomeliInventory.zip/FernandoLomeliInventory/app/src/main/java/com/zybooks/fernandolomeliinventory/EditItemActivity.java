package com.zybooks.fernandolomeliinventory;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

// This class was created to update item names and quantities or to delete an item
public class EditItemActivity extends AppCompatActivity {

    //Initialize fields
    EditText itemName, editTextQuantity;
    Button confirmChangesButton, deleteButton;
    String id, Name, Quantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_item);

        itemName = findViewById(R.id.itemName2);
        editTextQuantity = findViewById(R.id.editTextQuantity2);
        confirmChangesButton = findViewById(R.id.confirmChangesButton);
        deleteButton = findViewById(R.id.deleteButton);
        obtainIntentData();

        //Set confirm button to confirm the updates to the name and/or quantity of the item
        confirmChangesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ItemsDatabase itemsDatabase;
                itemsDatabase = new ItemsDatabase(EditItemActivity.this);
                Name=itemName.getText().toString().trim();
                Quantity=editTextQuantity.getText().toString().trim();
                itemsDatabase.editData(id, Name, Quantity);
                Intent intent = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(intent);
            }
        });

        //Sets the delete button to delete the selected item from the inventory list
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ItemsDatabase itemsDatabase;
                itemsDatabase = new ItemsDatabase(EditItemActivity.this);
                itemsDatabase.deleteData(id);
                finish();

            }
        });

    }

    void obtainIntentData() {
        if (getIntent().hasExtra("id") && getIntent().hasExtra("Name") &&
                getIntent().hasExtra("Quantity")) {
            id = getIntent().getStringExtra("id");
            Name = getIntent().getStringExtra("Name");
            Quantity = getIntent().getStringExtra("Quantity");

            itemName.setText(Name);
            editTextQuantity.setText(Quantity);

        }
    }
}