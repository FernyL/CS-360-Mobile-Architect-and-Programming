package com.zybooks.fernandolomeliinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

//SQLite database to hole item information
public class ItemsDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "itemInfo.db";
    private static final int VERSION = 1;
    private Context context;

    ItemsDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    //Initialize table with name and columns
    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " text, " +
                ItemTable.COL_QUANTITY + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    //Function to add items to the database
    public void addItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_QUANTITY, quantity);

        long itemId = db.insert(ItemTable.TABLE, null, values);
        if (itemId == -1) {
            Toast.makeText(context, "Failed to add item", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Item added", Toast.LENGTH_LONG).show();
        }
    }

    //Function to read data from database
    Cursor readData(){
        String query = "SELECT * FROM " + ItemTable.TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    //Function to update data in the database
    void editData(String row_id, String name, String quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_QUANTITY, quantity);
        long result = db.update(ItemTable.TABLE, values, "_id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Update failed", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Update successful", Toast.LENGTH_LONG).show();
        }
    }

    //function to delete an item from the database
    void deleteData(String row_id) {
        SQLiteDatabase db = this.getWritableDatabase();

        long result = db.delete(ItemTable.TABLE, "_id=?", new String[]{row_id});
        if (result == -1) {
            Toast.makeText(context, "Deletion failed", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Item deleted", Toast.LENGTH_LONG).show();
        }
    }
}
